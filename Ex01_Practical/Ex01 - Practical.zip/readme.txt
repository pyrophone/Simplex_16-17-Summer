Controls for camera:
W - Forward
S - Backward
A - Left
D - Right
E - Up
Q - Down

Format for stops for ini:
Stop: [x.x,y.y,z.z] (Same as the provided solution)

Theoretically, stops can be added in the code by pushing to the vector, but I don't
do in my code because using the ini is easier since I don't have to recompile